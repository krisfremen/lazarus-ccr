TestApp for LazAutoUpdate
==========================

Setup:
1. Lazarus should be able to compile to Win32,Win64,Linux32 and Linux64
2. Compile TestApp (Run/Compile many modes), but don't run it yet.
3. Copy latest_stable\updatehmsource\compiled folder to latest_stable\testapp\compiled folder.
   This will ensure the correct updatehmxxx(.exe) is in the same folder as the compiled testapp versions
4. Run Testapp, click 'AutoUpdate'.  As-is the online V0.1.0.0 should update your compiled V0.0.1.0

Now you know it's working properly on your system.